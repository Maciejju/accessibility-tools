// Copyright 2012 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

var contentScriptInjected = false;
var allScripts = null;

if (chrome.devtools.inspectedWindow.tabId) {
    chrome.extension.sendRequest({ tabId: chrome.devtools.inspectedWindow.tabId,
                                   command: 'injectContentScripts' }, init);
} else {
    init();
}

function init(result) {
    if (result) {
        if ('error' in result)
            console.warn('Could not inject content script; falling back to eval',
                         result.error);
        else
            contentScriptInjected = true;
    }
    if (!contentScriptInjected) {
        if (window.File && window.FileReader && window.FileList) {
            var scriptFiles = [ 'generated/axs.js',
                                'generated/constants.js',
                                'generated/utils.js',
                                'generated/properties.js',
                                'generated/extension_properties.js' ];
            var scripts = [];
            for (var i = 0; i < scriptFiles.length; i++) {
                try {
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', chrome.extension.getURL(scriptFiles[i]), false);
                    xhr.send();
                    scripts.push(xhr.responseText);
                } catch(ex) {
                    console.error('Could not get script "' + scriptFiles[i] + '";  aborting.',
                                  ex);
                    return;
                }

            }
            allScripts = scripts.join('\n') + '\n';
        }
    }

    chrome.devtools.panels.elements.createSidebarPane(
        chrome.i18n.getMessage('sidebarTitle'),
        function(sidebar) {
            sidebar.setPage("sidebar.html");
            sidebar.onShown.addListener(function(window) {
                window.sidebar = sidebar;
                window.sidebar.contentScriptInjected = contentScriptInjected;
                if (!contentScriptInjected)
                    window.sidebar.allScripts = allScripts;
                window.onSelectionChanged();
            });
        });
}
